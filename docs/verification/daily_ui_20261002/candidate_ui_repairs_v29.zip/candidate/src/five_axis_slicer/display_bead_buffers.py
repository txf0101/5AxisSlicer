"""OpenGL display-only bead cache and lighting helpers."""
from __future__ import annotations

from typing import Any, Callable

import numpy as np
from OpenGL.GL import (
    GL_FLOAT, GL_LINES, GL_LINE_STRIP, GL_TRIANGLES, glDepthMask, glDisableVertexAttribArray,
    glEnableVertexAttribArray, glUniform1f, glUniformMatrix3fv,
    glVertexAttrib3f, glVertexAttribPointer,
)
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QLabel
import ctypes

from .display_bead_mesh import BeadMesh, prepare_bead_sections
from .viewer_common import render_stride


def initialize(viewer: Any) -> None:
    viewer._normal_loc = viewer._normal_matrix_loc = viewer._lighting_loc = -1
    viewer._bead_lods = {}
    viewer._bead_sections = None
    viewer._visible_bead_segments = []
    viewer._active_solid_key = "path_solid"
    viewer._bead_display_info = {}
    viewer._bead_label = QLabel(viewer)
    viewer._bead_label.setWordWrap(True)
    viewer._bead_label.setAttribute(Qt.WA_TransparentForMouseEvents)
    viewer._bead_label.setStyleSheet("color: #334155; background: rgba(255,255,255,210); padding: 4px;")
    viewer._bead_label.move(8, 8)
    viewer._bead_label.hide()


def clear(viewer: Any) -> None:
    viewer._bead_lods.clear()
    viewer._bead_sections = None
    viewer._visible_bead_segments = []
    viewer._bead_label.hide()
    viewer._bead_display_info = {}


def ensure_detail(viewer: Any, sides: int, detail_limit: int,
                  builder: Callable[..., BeadMesh]) -> None:
    # Large views retain every segment with a smaller cross-section mesh.
    limited = len(viewer._visible_bead_segments) > detail_limit
    sides = 4 if limited else sides
    if sides not in viewer._bead_lods:
        if viewer._bead_sections is None:
            viewer._bead_sections = prepare_bead_sections(
                viewer._visible_bead_segments, viewer.gcode_preview.controller_semantics)
        mesh = builder(viewer._visible_bead_segments, sides=sides,
                       controller_semantics=viewer.gcode_preview.controller_semantics,
                       prepared=viewer._bead_sections)
        viewer._bead_lods[sides] = mesh
        key = "path_solid" if sides == 4 else "path_solid_detail"
        viewer._set_buffer(key, mesh.vertices, mesh.colors, GL_TRIANGLES, normals=mesh.normals)
    mesh = viewer._bead_lods[sides]
    viewer._active_solid_key = "path_solid" if sides == 4 else "path_solid_detail"
    viewer.drawn_path_segment_count = len(viewer._visible_bead_segments)
    viewer.path_render_mode = f"opengl_solid_lod{sides}" + ("_budget" if limited else "")
    _update_label(viewer, mesh, sides, limited)


def _update_label(viewer: Any, mesh: BeadMesh, sides: int, limited: bool) -> None:
    unspecified = any(s.display_dimensions_source != "generated_toolpath"
                      for s in viewer._visible_bead_segments if s.move_type == "extrude")
    viewer._bead_display_info = {"sides": sides, "nominal_geometry": True,
        "approximate_axis_segments": mesh.approximate_axis_count,
        "dimensions_source": "NC metadata or defaults 0.4x0.2 mm" if unspecified else "toolpath",
        "joined_segments": mesh.joined_count, "detail_limited": limited}
    note = " · axis approx / 姿态近似" if mesh.approximate_axis_count else ""
    dimensions = " · 宽厚 NC/默认 0.4×0.2 mm" if unspecified else ""
    detail_note = " · 大范围简化截面" if limited else ""
    viewer._bead_label.setText(f"Nominal bead / 名义料条 · LOD {sides}{note}{dimensions}{detail_note}")
    viewer._bead_label.setToolTip(viewer._bead_label.text())
    resize_label(viewer)
    viewer._bead_label.show()


def resize_label(viewer: Any) -> None:
    # 说明随视口换行，右侧为方向立方体保留 112px 及边距。
    viewer._bead_label.setFixedWidth(max(1, viewer.width() - 148))
    viewer._bead_label.adjustSize()


def prepare_lighting(viewer: Any) -> np.ndarray:
    view_matrix = viewer._view_matrix()
    glUniformMatrix3fv(viewer._normal_matrix_loc, 1, True,
                       np.asarray(view_matrix[:3, :3], dtype=np.float32))
    return view_matrix


def rebuild_paths(viewer: Any, solid: bool, current_step: int | None,
                  line_limit: int, line_builder: Callable[..., Any]) -> None:
    if viewer.gcode_preview is None:
        return
    visible = []
    for segment in viewer.gcode_preview.segments:
        if not viewer._segment_visible(segment) or not segment.has_spatial_length:
            continue
        if (current_step is not None and not viewer.preview_settings.show_upcoming
                and segment.step_index > current_step):
            continue
        visible.append(segment)
    viewer.visible_path_segment_count = len(visible)
    viewer._set_buffer("path_paper", [], [], GL_LINE_STRIP)
    viewer._bead_lods.clear()
    viewer._bead_sections = None
    viewer._visible_bead_segments = visible
    viewer._set_buffer("path_solid_detail", [], [], GL_TRIANGLES)
    viewer._set_buffer("path_solid", [], [], GL_TRIANGLES)
    if solid:
        viewer._solid_stride = 1
        viewer._set_buffer("path_line", [], [], GL_LINES)
        travel = [segment for segment in visible if segment.move_type != "extrude"]
        vertices, colors, _ = line_builder(travel, 1)
        viewer._set_buffer("path_travel", vertices, colors, GL_LINES)
    else:
        stride = render_stride(len(visible), line_limit)
        viewer.path_render_mode = ("opengl_line_interactive" if
            viewer._interaction_preview or viewer._progress_dragging else "opengl_line")
        vertices, colors, drawn = line_builder(visible, stride)
        viewer._set_buffer("path_line", vertices, colors, GL_LINES)
        viewer.drawn_path_segment_count = drawn
    viewer._refresh_pose_buffer(visible)
    first = visible[0].start if visible else None
    last = visible[-1].end if visible else None
    viewer._refresh_endpoint_buffers(first, last)


def draw_paths(viewer: Any, line_scale: float) -> int:
    count = viewer._draw_buffer(viewer._active_solid_key, line_width=1.0, depth_bias=0.0004)
    glDepthMask(False)
    try:
        return count + viewer._draw_buffer("path_travel", line_width=1.3 * line_scale)
    finally:
        glDepthMask(True)


def packed_attributes(buffer: Any) -> np.ndarray:
    attributes: tuple[np.ndarray, ...] = (buffer.vertices, buffer.colors)
    if buffer.normals is not None:
        attributes += (buffer.normals,)
    return np.hstack(attributes).astype(np.float32, copy=False)


def bind_normals(viewer: Any, key: str, buffer: Any, stride: int) -> None:
    lit = buffer.normals is not None and not key.endswith("_pick")
    glUniform1f(viewer._lighting_loc, float(lit))
    if lit:
        glEnableVertexAttribArray(viewer._normal_loc)
        glVertexAttribPointer(viewer._normal_loc, 3, GL_FLOAT, False, stride, ctypes.c_void_p(7 * 4))
    else:
        glDisableVertexAttribArray(viewer._normal_loc)
        glVertexAttrib3f(viewer._normal_loc, 0.0, 0.0, 1.0)
