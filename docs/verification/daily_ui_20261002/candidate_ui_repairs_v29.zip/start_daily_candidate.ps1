﻿param([switch]$VerifyOnly)
$ErrorActionPreference = 'Stop'
$candidateSource = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot 'candidate/src'))
$projectRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '../../../..'))
$candidatePython = Join-Path $projectRoot 'tmp/pytest9/Scripts/python.exe'
if (-not (Test-Path -LiteralPath $candidatePython)) { throw '已验证解释器不存在；此脚本不会安装依赖。' }
if (-not (Test-Path -LiteralPath (Join-Path $candidateSource 'five_axis_slicer/app.py'))) { throw '候选源码不存在。' }
$previousPythonPath = $env:PYTHONPATH
$previousQtPlatform = $env:QT_QPA_PLATFORM
$previousBackend = $env:FIVE_AXIS_RENDER_BACKEND
$candidateExitCode = 0
try {
    $env:PYTHONPATH = $candidateSource
    $env:QT_QPA_PLATFORM = 'windows'
    $env:FIVE_AXIS_RENDER_BACKEND = 'opengl'
    & $candidatePython -X utf8 -c 'import sys,pathlib,json,five_axis_slicer; from jsonschema import Draft202012Validator; from five_axis_slicer.setup_config import schema_path; actual=pathlib.Path(five_axis_slicer.__file__).resolve(); expected=pathlib.Path(sys.argv[1]).resolve(); assert actual.is_relative_to(expected), str(actual); resources=expected.parent/"schemas"; assert schema_path().resolve()==resources/"manufacturing-setup-v1.schema.json", "候选 Schema 缺失"; names=("manufacturing-setup-v1.schema.json","simulation_report_v1.schema.json","simulation_scene_v1.schema.json","simulation_source_v1.schema.json"); [Draft202012Validator.check_schema(json.loads((resources/n).read_text(encoding="utf-8"))) for n in names]; print("候选源码确认："+str(actual)); print("候选 Schema 确认：4 项")' $candidateSource
    if ($LASTEXITCODE -ne 0) { throw '候选源码或 Schema 核查失败，已停止启动。' }
    if (-not $VerifyOnly) {
        & $candidatePython -X utf8 -m five_axis_slicer
        $candidateExitCode = $LASTEXITCODE
    }
} finally {
    $env:PYTHONPATH = $previousPythonPath
    $env:QT_QPA_PLATFORM = $previousQtPlatform
    $env:FIVE_AXIS_RENDER_BACKEND = $previousBackend
}
exit $candidateExitCode
